<?php
     /*
     $first_name = $_POST["first_name"];
     $second_name = $_POST["second_name"];
     
     echo $first_name;
     echo $second_name;
     */
 $first_name = $_POST["first_name"];
 
 
 $second_name = $_POST["second_name"];
 
 echo "Name:<br>" . $first_name ;
 
 echo "<br>";
 echo "Second name:<br>" .  $second_name ;
 ?>